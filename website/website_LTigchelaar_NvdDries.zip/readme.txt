Auteurs:
Laura Tigchelaar (3970035)
Nicole van den Dries (5639050)

URL:
http://www.students.science.uu.nl/~5639050/website/

Browsers:
Google Chrome
Mozilla Firefox
Microsoft Edge
